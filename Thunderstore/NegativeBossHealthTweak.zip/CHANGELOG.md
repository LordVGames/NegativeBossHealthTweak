## 1.0.1

- Set mod as client-side (internally, not just the tag)

## 1.0.0

- First release