# NegativeBossHealthTweak

When a boss' health goes past the 32-bit integer limit (2,147,483,647), the numbers shown on the hud stop working properly and just show that integer limit but negative. This mod makes it show a bunch of question marks (10, the same amount of digits) when the health is past the limit.

## Before
![Risk_of_Rain_2_K48FH1E2pO](https://github.com/user-attachments/assets/3e78895c-88bb-4042-a532-f6b87ad62d02)

## After
![image](https://github.com/user-attachments/assets/8fad78ef-7b0d-44ae-8687-a49d855f85b5)

#### Once the "current health" number is below the integer limit:

![tiny](https://github.com/user-attachments/assets/83bce646-0cca-4a31-a6e8-5733f0e5ceb0)
